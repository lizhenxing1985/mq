package cn.itcast.activemq.topic;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQTextMessage;

/**
 * 消息生产者发送订阅消息
 * @author LEE.SIU.WAH
 * @email lixiaohua7@163.com
 * @date 2017年4月28日 上午10:15:18
 * @version 1.0
 */
public class ProducerTest {

	public static void main(String[] args) throws Exception{
		
		/** 定义brokerURL也就是activeMQ服务地址(tcp协议)*/
		String brokerURL = "tcp://192.168.12.128:61616";
		/** 创建ConnectionFactory连接工厂 */
		ConnectionFactory connectionFactory 
						= new ActiveMQConnectionFactory(brokerURL);
		/** 通过连接工厂创建连接对象 */
		Connection connection = connectionFactory.createConnection();
		/** 通过连接对象开启连接 */
		connection.start();
		/** 
		 * 通过连接对象创建session 
		 * 第一个参数：是否开启消息事务 true开启 false不开启
		 * 第二个参数：设置应答模式:
		 * 	 Session.AUTO_ACKNOWLEDGE 自动应答
		 *   Session.CLIENT_ACKNOWLEDGE: 客户端应答
		 *   Session.DUPS_OK_ACKNOWLEDGE: 重复确定应答
		 *   Session.SESSION_TRANSACTED: 会话事务
		 */
		Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		/** 通过Session创建订阅 */
		Topic topic = session.createTopic("test_topic");
		/** 通过Session创建消息生产者 */
		MessageProducer messageProducer = session.createProducer(topic);
		
		/** 创建消息体(文本消息体) */
		TextMessage textMessage = new ActiveMQTextMessage();
		/** 设置消息体的内容 */
		textMessage.setText("您好，jms 我来了 Topic!");
		
		/** 通过MessageProducer消息生产者发送消息 */
		messageProducer.send(textMessage);
		System.out.println("【生产者】已发送了消息：您好，jms 我来了Topic!");
		
		/** 关闭消息生产者、关闭Session、关闭Connection */
		messageProducer.close();
		session.close();
		connection.close();
	}
}