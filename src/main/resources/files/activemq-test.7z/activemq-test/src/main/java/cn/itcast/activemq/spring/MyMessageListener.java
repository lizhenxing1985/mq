package cn.itcast.activemq.spring;

import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;


/**
 * 自定义消息监听器
 * @author LEE.SIU.WAH
 * @email lixiaohua7@163.com
 * @date 2017年4月28日 下午3:40:31
 * @version 1.0
 */
public class MyMessageListener implements MessageListener{
	/** 处理消息方法 */
	@Override
	public void onMessage(Message message) {
		/** 判断消息类型 */
		if (message instanceof TextMessage){
			TextMessage textMessage = (TextMessage)message;
			try {
				System.out.println("MyMessageListener: " + textMessage.getText());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
