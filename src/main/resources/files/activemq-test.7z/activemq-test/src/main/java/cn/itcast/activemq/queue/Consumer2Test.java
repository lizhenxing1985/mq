package cn.itcast.activemq.queue;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;

/**
 * 消费者Consumer消费queue消息
 * @author LEE.SIU.WAH
 * @email lixiaohua7@163.com
 * @date 2017年4月28日 上午11:46:25
 * @version 1.0
 */
public class Consumer2Test {

	public static void main(String[] args) throws Exception {
		
		/** 定义activeMQ服务地址(tcp协议)*/
		String brokerURL = "tcp://192.168.12.128:61616";
		/** 创建ConnectionFactory连接工厂 */
		ConnectionFactory connectionFactory = 
				new ActiveMQConnectionFactory(brokerURL);
		/** 通过连接工厂创建Connection连接对象 */
		Connection connection = connectionFactory.createConnection();
		/** 通过Connection开启连接 */
		connection.start();
		/** 通过Connection连接创建Session */
		Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		
		/** 通过Session创建queue队列(点对点) */
		Queue queue = session.createQueue("test_queue");
		/** 通过Session创建消费者 */
		MessageConsumer messageConsumer = session.createConsumer(queue);
		
		/** 消费消息: 第二种方式(设置消息监听器) */
		messageConsumer.setMessageListener(new MessageListener() {
			@Override
			public void onMessage(Message message){
				/** 判断消息的类型 */
				if (message instanceof TextMessage){
					/** 类型转换 */
					TextMessage textMessage = (TextMessage)message;
					try{
						/** 获取接收到得消息 */
						System.out.println(textMessage.getText());
					}catch(Exception ex){
						ex.printStackTrace();
					}
				}
			}
		});
		
		/** 关闭消息消费者、关闭Session、关闭Connection */
		messageConsumer.close();
		session.close();
		connection.close();
		
	}

}
