/**   
* @Title: UserDaoImpl.java 
* @Package cn.itheima.ssm.dao.impl 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-7 下午12:13:50 
* @version V1.0   
*/
package cn.itheima.ssm.dao.impl;

import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import cn.itheima.ssm.dao.UserDao;
import cn.itheima.ssm.po.User;

/** 
 * @ClassName: UserDaoImpl 
 * @Description: 用户dao实现类
 * @author 传智 小杨老师  
 * @date 2017-11-7 下午12:13:50 
 *  
 */
public class UserDaoImpl extends SqlSessionDaoSupport implements UserDao {

	/* (non-Javadoc)
	 * @see cn.itheima.ssm.dao.UserDao#queryUserById(java.lang.Integer)
	 */
	public User queryUserById(Integer id) {
		// TODO Auto-generated method stub
		// 1.获取sqlSession对象
		SqlSession sqlSession = this.getSqlSession();
		
		// 2.使用sqlSession对象，调用方法执行
		Object user = sqlSession.selectOne("test.queryUserById", id);
		
		// 说明：
		// 1.与spring整合以后，sqlSession对象交给spring管理，不需要再手动释放（不能）
		
		return (User) user;
	}

	/* (non-Javadoc)
	 * @see cn.itheima.ssm.dao.UserDao#insertUser(cn.itheima.ssm.po.User)
	 */
	public void insertUser(User user) {
		// TODO Auto-generated method stub
		// 1.获取sqlSession对象
		SqlSession sqlSession = this.getSqlSession();
		
		// 2.使用sqlSession对象，调用方法执行
		sqlSession.insert("test.insertUser", user);
		
		// 说明：
		// 1.与spring整合以后，sqlSession对象交给spring管理，不需要再手动释放（不能）
		// 2.与spring整合以后，sqlSession对象交给spring管理，不需要再手动提交事务（不能）
		// 如果配置了spring的事务，使用的spring事务，如果没有配置，默认使用jdbc事务

	}

}
