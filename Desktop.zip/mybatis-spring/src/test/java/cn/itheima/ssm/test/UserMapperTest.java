/**   
* @Title: UserMapperTest.java 
* @Package cn.itheima.ssm.test 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-7 下午12:33:54 
* @version V1.0   
*/
package cn.itheima.ssm.test;

import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.itheima.ssm.mapper.UserMapper;
import cn.itheima.ssm.po.User;
import cn.itheima.ssm.po.UserExample;
import cn.itheima.ssm.po.UserExample.Criteria;

/** 
 * @ClassName: UserMapperTest 
 * @Description: 用户mapper测试
 * @author 传智 小杨老师  
 * @date 2017-11-7 下午12:33:54 
 *  
 */
public class UserMapperTest {
	
	// 测试根据用户名称模糊查询用户
	@Test
	public void queryUserByNameTest(){
		
		// 1.加载spring配置文件
		ClassPathXmlApplicationContext context = 
				new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
		
		// 2.使用context对象，获取用户mapper对象
		UserMapper userMapper = (UserMapper) context.getBean("userMapper");
		
		// 3.使用userMapper调用方法执行
		// 3.1.创建辅助类对象
		UserExample example = new UserExample();
		
		// 3.2.使用example对象，创建Criteria对象
		Criteria cri = example.createCriteria();
		
		// 3.3.使用Criteria对象，通过andXXX方法，设置where条件
		cri.andUsernameLike("%小明%");

		List<User> list = userMapper.selectByExample(example);
		for(User u:list){
			System.out.println(u);
		}
		
	}
	
	// 测试新增用户
	@Test
	public void insertUserTest(){
		// 1.加载spring配置文件
		ClassPathXmlApplicationContext context = 
				new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
		
		// 2.使用context对象，获取用户mapper对象
		UserMapper userMapper = (UserMapper) context.getBean("userMapper");
		
		// 3.使用userMapper调用方法执行
		// 创建用户对象
		User user = new User();
		user.setUsername("赵刚");
		user.setBirthday(new Date());
		user.setSex("1");
		user.setAddress("燕京大学");
		
		userMapper.insertSelective(user);
		
	}

}
