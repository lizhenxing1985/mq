/**   
* @Title: UserDao.java 
* @Package cn.itheima.mybatis.dao 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-6 上午10:53:35 
* @version V1.0   
*/
package cn.itheima.mybatis.dao;

import cn.itheima.mybatis.po.User;

/** 
 * @ClassName: UserDao 
 * @Description: 用户dao接口
 * @author 传智 小杨老师  
 * @date 2017-11-6 上午10:53:35 
 *  
 */
public interface UserDao {
	
//	1.根据用户Id查询用户
	User queryUserById(Integer id);
	
//	2.新增用户
	void insertUser(User user);

}
