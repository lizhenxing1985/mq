/**   
* @Title: UserDaoImpl.java 
* @Package cn.itheima.mybatis.dao.impl 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-6 上午10:55:16 
* @version V1.0   
*/
package cn.itheima.mybatis.dao.impl;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import cn.itheima.mybatis.dao.UserDao;
import cn.itheima.mybatis.po.User;

/** 
 * @ClassName: UserDaoImpl 
 * @Description: 用户dao接口实现
 * @author 传智 小杨老师  
 * @date 2017-11-6 上午10:55:16 
 *  
 */
public class UserDaoImpl implements UserDao {
	
	// 定义sqlSessionFactory对象
	private SqlSessionFactory sqlSessionFactory;

	/**
	 * 
	 */
	public UserDaoImpl() {
		super();
	}

	/**
	 * @param sqlSessionFactory
	 */
	public UserDaoImpl(SqlSessionFactory sqlSessionFactory) {
		super();
		this.sqlSessionFactory = sqlSessionFactory;
	}

	/* (non-Javadoc)
	 * @see cn.itheima.mybatis.dao.UserDao#queryUserById(java.lang.Integer)
	 */
	public User queryUserById(Integer id) {
		// TODO Auto-generated method stub
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession();
		
		// 2.使用sqlSession对象，调用方法执行
		Object user = sqlSession.selectOne("test.queryUserById", id);
		
		// 3.释放资源
		sqlSession.close();
		
		return (User) user;
	}

	/* (non-Javadoc)
	 * @see cn.itheima.mybatis.dao.UserDao#insertUser(cn.itheima.mybatis.po.User)
	 */
	public void insertUser(User user) {
		// TODO Auto-generated method stub
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession(true);
		
		// 2.使用sqlSession对象，调用方法执行
		sqlSession.insert("test.insertUser", user);
		
		// 3.释放资源
		sqlSession.close();

	}

}
