/**   
* @Title: UserMapper.java 
* @Package cn.itheima.mybatis.mapper 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-6 上午11:10:59 
* @version V1.0   
*/
package cn.itheima.mybatis.mapper;

import org.apache.ibatis.annotations.Select;

import cn.itheima.mybatis.po.User;

/** 
 * @ClassName: UserMapper 
 * @Description: 用户mapper接口 
 * @author 传智 小杨老师  
 * @date 2017-11-6 上午11:10:59 
 *  
 */
public interface UserMapper {
	
//	1.根据用户Id查询用户
	User queryUserById(Integer id);
	
//	2.新增用户
	void insertUser(User user);
	
	
//	3.根据用户Id查询用户，使用注解开发实现
	@Select("select * from `user` where id=#{id}")
	User queryUserById_1(Integer id);

}
