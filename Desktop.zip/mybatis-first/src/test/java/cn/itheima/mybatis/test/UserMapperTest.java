/**   
* @Title: UserMapperTest.java 
* @Package cn.itheima.mybatis.test 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-6 上午11:17:03 
* @version V1.0   
*/
package cn.itheima.mybatis.test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import cn.itheima.mybatis.mapper.UserMapper;
import cn.itheima.mybatis.po.User;

/** 
 * @ClassName: UserMapperTest 
 * @Description: mapper代理开发方法测试
 * @author 传智 小杨老师  
 * @date 2017-11-6 上午11:17:03 
 *  
 */
public class UserMapperTest {
	
	private SqlSessionFactory sqlSessionFactory = null;
	
	@Before
	public void init() throws IOException{
		// 1.加载核心配置文件：sqlMapConfig.xml
		// resource属性：指定核心配置文件位置
		InputStream inputStream = Resources.getResourceAsStream("sqlMapConfig.xml");
		
		// 2.读取配置文件内容
		SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
		// SqlSessionFactory对象：mybatis框架的核心对象，一个项目中只需要一个（单例设计模式）
		sqlSessionFactory = builder.build(inputStream);
	}
	
	// 测试根据用户Id查询用户
	@Test
	public void queryUserByIdTest(){
		
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession();
		
		// 2.使用sqlSession对象，获取mapper代理对象
		// getMapper方法：获取mapper代理对象
		// type参数：mapper接口的class
		UserMapper mapper = sqlSession.getMapper(UserMapper.class);
		
		// 3.使用mapper代理对象，调用方法执行
		User user = mapper.queryUserById(2);
		System.out.println(user);
		
		// 4.释放资源
		sqlSession.close();
	}
	
	// 测试新增用户
	@Test
	public void insertUserTest(){
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession(true);
		
		// 2.使用sqlSession对象，获取mapper代理对象
		UserMapper mapper = sqlSession.getMapper(UserMapper.class);
		
		// 3.使用mapper对象，调用方法执行
		// 创建用户对象
		User user = new User();
		user.setUsername("天机老人");
		user.setSex("1");
		user.setBirthday(new Date());
		user.setAddress("来自大明朝");
		
		mapper.insertUser(user);
		
		// 4.释放资源
		sqlSession.close();
	}
	
	// 测试根据用户Id查询用户,测试注解开发
	@Test
	public void queryUserById_1Test(){
		
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession();
		
		// 2.使用sqlSession对象，获取mapper代理对象
		// getMapper方法：获取mapper代理对象
		// type参数：mapper接口的class
		UserMapper mapper = sqlSession.getMapper(UserMapper.class);
		
		// 3.使用mapper代理对象，调用方法执行
		User user = mapper.queryUserById_1(2);
		System.out.println(user);
		
		// 4.释放资源
		sqlSession.close();
	}
	
	// 测试根据用户Id查询用户,测试一级缓存
	@Test
	public void oneCacheTest(){
		
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession();
		
		// 2.使用sqlSession对象，获取mapper代理对象
		// getMapper方法：获取mapper代理对象
		// type参数：mapper接口的class
		UserMapper mapper = sqlSession.getMapper(UserMapper.class);
		
		// 3.使用mapper代理对象，调用方法执行
		User user = mapper.queryUserById(2);
		System.out.println(user);
		
		System.out.println("-------------------------------------");
		
		User user1 = mapper.queryUserById(2);
		System.out.println(user1);
		
		
		// 4.释放资源
		sqlSession.close();
	}
	
	// 测试根据用户Id查询用户,测试二级缓存
	@Test
	public void twoCacheTest(){
		
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession();
		
		// 2.使用sqlSession对象，获取mapper代理对象
		// getMapper方法：获取mapper代理对象
		// type参数：mapper接口的class
		UserMapper mapper = sqlSession.getMapper(UserMapper.class);
		
		// 3.使用mapper代理对象，调用方法执行
		User user = mapper.queryUserById(2);
		System.out.println(user);

		// 4.释放资源
		sqlSession.close();
		
		System.out.println("-----------------------------------------");
		
		//  5.创建sqlSession对象
		SqlSession sqlSession1 = this.sqlSessionFactory.openSession();
		
		// 6.使用sqlSession对象，获取mapper代理对象
		// getMapper方法：获取mapper代理对象
		// type参数：mapper接口的class
		UserMapper mapper1 = sqlSession1.getMapper(UserMapper.class);
		
		// 7.使用mapper代理对象，调用方法执行
		User user1 = mapper1.queryUserById(2);
		System.out.println(user1);

		// 8.释放资源
		sqlSession1.close();
	}

}
