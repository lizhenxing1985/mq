/**   
* @Title: JdbcTest.java 
* @Package cn.itheima.mybatis.test 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-6 上午8:37:28 
* @version V1.0   
*/
package cn.itheima.mybatis.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/** 
 * @ClassName: JdbcTest 
 * @Description: jdbc示例程序
 * @author 传智 小杨老师  
 * @date 2017-11-6 上午8:37:28 
 *  
 */
public class JdbcTest {

	/** 
	 * @Title: main 
	 * @Description: TODO(这里用一句话描述这个方法的作用) 
	 * @param args    设定文件 
	 * @return void    返回类型 
	 * @throws 
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement psmt = null;
		ResultSet set = null;
		try{
//			1.加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			
//			2.创建数据库连接对象
			con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/mybatis", "root", "admin");
			
//			3.定义sql
			String sql = "select * from `user` where id=?";
//			4.创建statement语句对象
			psmt = con.prepareStatement(sql);
			
//			5.设置参数
			psmt.setInt(1, 24);
			
//			6.执行
			set = psmt.executeQuery();
			
//			7.处理结果集
			while(set.next()){
				System.out.println("用户Id："+set.getInt("id")+",用户名称："+set.getString("username"));
			}
			

		}catch(Exception e){
			e.printStackTrace();
		}finally{
//			8.释放资源
			try{
				if(set != null) set.close();
				if(psmt != null) psmt.close();
				if(con != null) con.close();
			}catch(Exception e){
				e.printStackTrace();
			}
			
			
		}


	}

}
