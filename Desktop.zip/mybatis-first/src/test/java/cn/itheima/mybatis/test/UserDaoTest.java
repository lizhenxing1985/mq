/**   
* @Title: UserDaoTest.java 
* @Package cn.itheima.mybatis.test 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-6 上午10:59:59 
* @version V1.0   
*/
package cn.itheima.mybatis.test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import cn.itheima.mybatis.dao.UserDao;
import cn.itheima.mybatis.dao.impl.UserDaoImpl;
import cn.itheima.mybatis.po.User;

/** 
 * @ClassName: UserDaoTest 
 * @Description: 原始的dao开发方法测试 
 * @author 传智 小杨老师  
 * @date 2017-11-6 上午10:59:59 
 *  
 */
public class UserDaoTest {
	
	private SqlSessionFactory sqlSessionFactory = null;
	
	@Before
	public void init() throws IOException{
		// 1.加载核心配置文件：sqlMapConfig.xml
		// resource属性：指定核心配置文件位置
		InputStream inputStream = Resources.getResourceAsStream("sqlMapConfig.xml");
		
		// 2.读取配置文件内容
		SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
		// SqlSessionFactory对象：mybatis框架的核心对象，一个项目中只需要一个（单例设计模式）
		sqlSessionFactory = builder.build(inputStream);
	}
	
	// 测试根据用户Id查询用户
	@Test
	public void queryUserByIdTest(){
		
		// 1.创建用户dao对象
		UserDao userDao = new UserDaoImpl(sqlSessionFactory);
		
		// 2.使用userDao对象，调用方法执行
		User user = userDao.queryUserById(2);
		System.out.println(user);
		
	}
	
	// 测试新增用户
	@Test
	public void insertUserTest(){
		// 1.创建用户dao对象
		UserDao userDao = new UserDaoImpl(sqlSessionFactory);
		
		// 2.使用userDao对象，调用方法执行
		// 创建用户对象
		User user = new User();
		user.setUsername("阿飞");
		user.setSex("1");
		user.setBirthday(new Date());
		user.setAddress("来自大明朝");
		
		System.out.println("执行前："+user);
		userDao.insertUser(user);
		System.out.println("执行后："+user);
	}

}
