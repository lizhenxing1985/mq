/**   
* @Title: MybatisTest.java 
* @Package cn.itheima.mybatis.test 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-6 上午9:13:06 
* @version V1.0   
*/
package cn.itheima.mybatis.test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import cn.itheima.mybatis.po.User;

/** 
 * @ClassName: MybatisTest 
 * @Description: mybatis入门程序测试
 * @author 传智 小杨老师  
 * @date 2017-11-6 上午9:13:06 
 *  
 */
public class MybatisTest {
	
	private SqlSessionFactory sqlSessionFactory = null;
	
	@Before
	public void init() throws IOException{
		// 1.加载核心配置文件：sqlMapConfig.xml
		// resource属性：指定核心配置文件位置
		InputStream inputStream = Resources.getResourceAsStream("sqlMapConfig.xml");
		
		// 2.读取配置文件内容
		SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
		// SqlSessionFactory对象：mybatis框架的核心对象，一个项目中只需要一个（单例设计模式）
		sqlSessionFactory = builder.build(inputStream);
	}
	
	// 1.测试根据用户Id查询用户
	@Test
	public void queryUserByIdTest() throws IOException{
		
		// 1.加载核心配置文件：sqlMapConfig.xml
		// resource属性：指定核心配置文件位置
		InputStream inputStream = Resources.getResourceAsStream("sqlMapConfig.xml");
		
		// 2.读取配置文件内容
		SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
		// SqlSessionFactory对象：mybatis框架的核心对象，一个项目中只需要一个（单例设计模式）
		SqlSessionFactory sqlSessionFactory = builder.build(inputStream);
		
		// 3.使用SqlSessionFactory对象，创建sqlSession对象
		// sqlSession对象：
		// 3.1相当于jdbc中的connection对象
		// 3.2 sqlSession对象是线程不安全，每一个执行操作的方法，都需要创建一个sqlSession对象
		SqlSession sqlSession = sqlSessionFactory.openSession();
		
		// 4.使用sqlSession对象，调用方法执行
		// selectOne方法：查询单条记录
		// statement参数：执行的sql语句（名称空间+sql语句Id）
		// parameter参数：传入的参数值
		Object user = sqlSession.selectOne("test.queryUserById", 24);
		System.out.println(user);
		
		// 5.释放资源
		sqlSession.close();
		
	}
	
	// 2.测试根据用户名称模糊查询用户
	@Test
	public void queryUserByNameTest() throws IOException{
		// 1.加载核心配置文件
		InputStream inputStream = Resources.getResourceAsStream("sqlMapConfig.xml");
		
		// 2.读取配置文件内容
		SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
		SqlSessionFactory sqlSessionFactory = builder.build(inputStream);
		
		// 3.使用sqlSessionFactory对象，创建sqlSession对象
		SqlSession sqlSession = sqlSessionFactory.openSession();
		
		// 4.使用sqlSession对象，调用方法执行
		// selectList方法：查询多条记录
		// statement参数：执行的sql语句（名称空间+sql语句Id）
		// parameter参数：传入的参数值
		List<Object> list = sqlSession.selectList("test.queryUserByName", "%小明%");
		
		//List<Object> list = sqlSession.selectList("test.queryUserByName", "小明");
		for(Object o :list){
			System.out.println(o);
		}
		
		// 5.释放资源
		sqlSession.close();
	}
	
	// 3.测试新增用户
	@Test
	public void insertUserTest(){
		// 1.创建sqlSession对象
		//SqlSession sqlSession = sqlSessionFactory.openSession();
		
		// 创建sqlSession对象，指定自动提交事务。true：表示提交；false：表示不提交。默认是false
		SqlSession sqlSession =  this.sqlSessionFactory.openSession(true);
		
		// 2.使用sqlSession对象，调用方法执行
		// insert方法：新增记录
		// statement参数：执行的sql语句（名称空间+sql语句Id）
		// parameter参数：传入的参数值
		// 创建用户对象
		User user  = new User();
		//user.setId(4);
		user.setUsername("林诗音");
		user.setBirthday(new Date());
		user.setSex("2");
		user.setAddress("来自大明朝");
		
		System.out.println("执行前："+user);
		sqlSession.insert("test.insertUser", user);
		System.out.println("执行后："+user);
		
		// 数据库提交事务：commit
		//sqlSession.commit();
		
		// 3.释放资源
		sqlSession.close();
		
	}
	
	// 4.测试根据用户Id修改用户
	@Test
	public void updateUserByIdTest(){
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession(true);
		
		// 2.使用sqlSession对象，调用方法执行
		// update方法：修改记录
		// statement参数：执行的sql语句（名称空间+sql语句Id）
		// parameter参数：传入的参数值
		// 创建用户对象
		User user = new User();
		user.setId(3);
		user.setUsername("林诗音和小李飞刀");
		user.setSex("1");
		
		sqlSession.update("test.updateUserById", user);
		
		// 3.释放资源
		sqlSession.close();
	}
	
	// 5.测试根据用户Id删除用户
	@Test
	public void deleteUserByIdTest(){
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession(true);
		
		// 2.使用sqlSession对象，调用方法执行
		// delete方法：删除记录
		// statement参数：执行的sql语句（名称空间+sql语句Id）
		// parameter参数：传入的参数值
		sqlSession.delete("test.deleteUserById", 35);
		
		// 3.释放资源
		sqlSession.close();
	}
	

}
