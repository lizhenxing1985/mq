/**   
* @Title: Orders.java 
* @Package cn.itheima.mybatis.po 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-7 上午9:13:28 
* @version V1.0   
*/
package cn.itheima.mybatis.po;

import java.util.Date;

/** 
 * @ClassName: Orders 
 * @Description: 订单pojo
 * @author 传智 小杨老师  
 * @date 2017-11-7 上午9:13:28 
 *  
 */
public class Orders {
	
	  private Integer id; // int(11) NOT NULL AUTO_INCREMENT,
	  
	  // user_id
	  private Integer userId; // int(11) NOT NULL COMMENT '下单用户id',
	  
	  private String number; // varchar(32) NOT NULL COMMENT '订单号',
	  private Date createtime; // datetime NOT NULL COMMENT '创建订单时间',
	  private String note; // varchar(100) DEFAULT NULL COMMENT '备注',
	  
	  // 定义用户对象属性
	  private User user;

	  
	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}
	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		this.user = user;
	}
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the userId
	 */
	public Integer getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	/**
	 * @return the number
	 */
	public String getNumber() {
		return number;
	}
	/**
	 * @param number the number to set
	 */
	public void setNumber(String number) {
		this.number = number;
	}
	/**
	 * @return the createtime
	 */
	public Date getCreatetime() {
		return createtime;
	}
	/**
	 * @param createtime the createtime to set
	 */
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	/**
	 * @return the note
	 */
	public String getNote() {
		return note;
	}
	/**
	 * @param note the note to set
	 */
	public void setNote(String note) {
		this.note = note;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Orders [id=" + id + ", userId=" + userId + ", number=" + number
				+ ", createtime=" + createtime + ", note=" + note + "]";
	}
	  
	  

}
