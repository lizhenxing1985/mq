/**   
* @Title: User.java 
* @Package cn.itheima.mybatis.po 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-6 上午9:02:43 
* @version V1.0   
*/
package cn.itheima.mybatis.po;

import java.util.Date;
import java.util.List;

/** 
 * @ClassName: User 
 * @Description: 用户pojo
 * @author 传智 小杨老师  
 * @date 2017-11-6 上午9:02:43 
 *  
 */
public class User{
	
	  private Integer id; // int(11) NOT NULL AUTO_INCREMENT,
	  private String username; // varchar(32) NOT NULL COMMENT '用户名称',
	  private Date birthday; // date DEFAULT NULL COMMENT '生日',
	  private String sex; // char(1) DEFAULT NULL COMMENT '性别',
	  private String address; // varchar(256) DEFAULT NULL COMMENT '地址',
	  
	  // 订单集合属性list
	  private List<Orders> ordersList;

	/**
	 * @return the ordersList
	 */
	public List<Orders> getOrdersList() {
		return ordersList;
	}
	/**
	 * @param ordersList the ordersList to set
	 */
	public void setOrdersList(List<Orders> ordersList) {
		this.ordersList = ordersList;
	}
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @return the birthday
	 */
	public Date getBirthday() {
		return birthday;
	}
	/**
	 * @param birthday the birthday to set
	 */
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	/**
	 * @return the sex
	 */
	public String getSex() {
		return sex;
	}
	/**
	 * @param sex the sex to set
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", birthday="
				+ birthday + ", sex=" + sex + ", address=" + address + "]";
	}
	  
	  

}
