/**   
* @Title: QueryVo.java 
* @Package cn.itheima.mybatis.po 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-7 上午8:53:27 
* @version V1.0   
*/
package cn.itheima.mybatis.po;

/** 
 * @ClassName: QueryVo 
 * @Description: pojo包装类型 
 * @author 传智 小杨老师  
 * @date 2017-11-7 上午8:53:27 
 *  
 */
public class QueryVo {
	
	// 包装用户
	private User user;

	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		this.user = user;
	}
	
	

}
