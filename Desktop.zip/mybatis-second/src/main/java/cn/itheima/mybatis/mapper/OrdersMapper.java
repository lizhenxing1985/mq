/**   
* @Title: OrdersMapper.java 
* @Package cn.itheima.mybatis.mapper 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-7 上午9:16:02 
* @version V1.0   
*/
package cn.itheima.mybatis.mapper;

import java.util.List;

import cn.itheima.mybatis.po.Orders;

/** 
 * @ClassName: OrdersMapper 
 * @Description: 订单mapper接口
 * @author 传智 小杨老师  
 * @date 2017-11-7 上午9:16:02 
 *  
 */
public interface OrdersMapper {
	
	// 1.查询全部订单数据
	List<Orders> queryAllOrders();
	
	// 2.查询全部订单数据,使用resultMap实现
	List<Orders> queryAllOrdersByResultMap();
	
	// 3.查询订单数据，并且关联查询出所属的用户数据
	List<Orders> queryOrdersAndUsers();

}
