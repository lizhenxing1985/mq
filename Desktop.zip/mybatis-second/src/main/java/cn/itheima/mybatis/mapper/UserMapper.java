/**   
* @Title: UserMapper.java 
* @Package cn.itheima.mybatis.mapper 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-6 上午11:10:59 
* @version V1.0   
*/
package cn.itheima.mybatis.mapper;

import java.util.List;

import cn.itheima.mybatis.po.QueryVo;
import cn.itheima.mybatis.po.User;

/** 
 * @ClassName: UserMapper 
 * @Description: 用户mapper接口 
 * @author 传智 小杨老师  
 * @date 2017-11-6 上午11:10:59 
 *  
 */
public interface UserMapper {
	
//	1.根据用户Id查询用户
	User queryUserById(Integer id);
	
//	2.新增用户
	void insertUser(User user);
	
	// 3.使用pojo包装类型，实现根据用户名称模糊查询用户
	List<User> queryUserByCondition(QueryVo queryVo);
	
	// 4.统计用户数量
	Integer countUsers();
	
	// 5.根据用户名称和性别查询用户
	List<User> queryUserByNameAndSex(User user);
	
	// 6.动态修改用户数据
	void dynamicUserById(User user);
	
	// 7.批量新增用户
	void batchInsertUser(List<User> list);
	
	// 8.批量删除用户
	void batchDeleteUser(Integer[] ids);
	
	// 9.查询用户数据，并且关联查询出所有的订单数据
	List<User> queryUsersAndOrders();


}
