/**   
* @Title: OrdersMapperTest.java 
* @Package cn.itheima.mybatis.test 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-7 上午9:19:33 
* @version V1.0   
*/
package cn.itheima.mybatis.test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import cn.itheima.mybatis.mapper.OrdersMapper;
import cn.itheima.mybatis.po.Orders;

/** 
 * @ClassName: OrdersMapperTest 
 * @Description: 订单mapper测试
 * @author 传智 小杨老师  
 * @date 2017-11-7 上午9:19:33 
 *  
 */
public class OrdersMapperTest {
	
	private SqlSessionFactory sqlSessionFactory = null;
	
	@Before
	public void init() throws IOException{
		// 1.加载核心配置文件：sqlMapConfig.xml
		// resource属性：指定核心配置文件位置
		InputStream inputStream = Resources.getResourceAsStream("sqlMapConfig.xml");
		
		// 2.读取配置文件内容
		SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
		// SqlSessionFactory对象：mybatis框架的核心对象，一个项目中只需要一个（单例设计模式）
		sqlSessionFactory = builder.build(inputStream);
	}
	
	// 测试查询全部订单数据
	@Test
	public void queryAllOrdersTest(){
		
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession();
		
		// 2.使用sqlSession对象，获取mapper对象
		OrdersMapper mapper = sqlSession.getMapper(OrdersMapper.class);
		
		// 3.使用mapper对象，调用方法执行
		List<Orders> list = mapper.queryAllOrders();
		for(Orders o:list){
			System.out.println(o);
		}
		
		// 4.释放资源
		sqlSession.close();
		
	}
	
	// 测试查询全部订单数据,使用resultMap实现
	@Test
	public void queryAllOrdersByResultMapTest(){
		
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession();
		
		// 2.使用sqlSession对象，获取mapper对象
		OrdersMapper mapper = sqlSession.getMapper(OrdersMapper.class);
		
		// 3.使用mapper对象，调用方法执行
		List<Orders> list = mapper.queryAllOrdersByResultMap();
		for(Orders o:list){
			System.out.println(o);
		}
		
		// 4.释放资源
		sqlSession.close();
		
	}
	
	// 测试查询订单数据，并且关联查询出所属的用户数据
	@Test
	public void queryOrdersAndUsersTest(){
		
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession();
		
		// 2.使用sqlSession对象，获取mapper对象
		OrdersMapper mapper = sqlSession.getMapper(OrdersMapper.class);
		
		// 3.使用mapper对象，调用方法执行
		List<Orders> list = mapper.queryOrdersAndUsers();
		for(Orders o:list){
			System.out.println(o);
		}
		
		// 4.释放资源
		sqlSession.close();
		
	}

}
