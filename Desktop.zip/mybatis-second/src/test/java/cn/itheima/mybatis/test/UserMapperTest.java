/**   
* @Title: UserMapperTest.java 
* @Package cn.itheima.mybatis.test 
* @Description: TODO(用一句话描述该文件做什么) 
* @author 传智 小杨老师 
* @date 2017-11-6 上午11:17:03 
* @version V1.0   
*/
package cn.itheima.mybatis.test;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import cn.itheima.mybatis.mapper.UserMapper;
import cn.itheima.mybatis.po.QueryVo;
import cn.itheima.mybatis.po.User;

/** 
 * @ClassName: UserMapperTest 
 * @Description: mapper代理开发方法测试
 * @author 传智 小杨老师  
 * @date 2017-11-6 上午11:17:03 
 *  
 */
public class UserMapperTest {
	
	private SqlSessionFactory sqlSessionFactory = null;
	
	@Before
	public void init() throws IOException{
		// 1.加载核心配置文件：sqlMapConfig.xml
		// resource属性：指定核心配置文件位置
		InputStream inputStream = Resources.getResourceAsStream("sqlMapConfig.xml");
		
		// 2.读取配置文件内容
		SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
		// SqlSessionFactory对象：mybatis框架的核心对象，一个项目中只需要一个（单例设计模式）
		sqlSessionFactory = builder.build(inputStream);
	}
	
	// 测试根据用户Id查询用户
	@Test
	public void queryUserByIdTest(){
		
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession();
		
		// 2.使用sqlSession对象，获取mapper代理对象
		// getMapper方法：获取mapper代理对象
		// type参数：mapper接口的class
		UserMapper mapper = sqlSession.getMapper(UserMapper.class);
		
		// 3.使用mapper代理对象，调用方法执行
		User user = mapper.queryUserById(2);
		System.out.println(user);
		
		// 4.释放资源
		sqlSession.close();
	}
	
	// 测试新增用户
	@Test
	public void insertUserTest(){
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession(true);
		
		// 2.使用sqlSession对象，获取mapper代理对象
		UserMapper mapper = sqlSession.getMapper(UserMapper.class);
		
		// 3.使用mapper对象，调用方法执行
		// 创建用户对象
		User user = new User();
		user.setUsername("天机老人");
		user.setSex("1");
		user.setBirthday(new Date());
		user.setAddress("来自大明朝");
		
		mapper.insertUser(user);
		
		// 4.释放资源
		sqlSession.close();
	}
	
	// 测试使用pojo包装类型，实现根据用户名称模糊查询用户
	@Test
	public void queryUserByConditionTest(){
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession();
		
		// 2.使用sqlSession对象，获取mapper代理对象
		UserMapper mapper = sqlSession.getMapper(UserMapper.class);
		
		// 3.使用mapper对象，调用方法执行
		// 创建包装类型pojo
		QueryVo queryVo = new QueryVo();
		
		// 创建用户对象
		User user = new User();
		user.setUsername("小");
		
		queryVo.setUser(user);
		
		List<User> list = mapper.queryUserByCondition(queryVo);
		for(User u:list){
			System.out.println(u);
		}
		
		// 4.释放资源
		sqlSession.close();
	}
	
	// 测试统计用户数量
	@Test
	public void countUsersTest(){
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession();
		
		// 2.使用sqlSession对象，获取mapper代理对象
		UserMapper mapper = sqlSession.getMapper(UserMapper.class);
		
		// 3.使用mapper对象，调用方法执行
		Integer users = mapper.countUsers();
		System.out.println("当前的用户数量："+users);
		
		// 4.释放资源
		sqlSession.close();
	}
	
	// 测试根据用户名称和性别查询用户
	@Test
	public void queryUserByNameAndSexTest(){
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession();
		
		// 2.使用sqlSession对象，获取mapper代理对象
		UserMapper mapper = sqlSession.getMapper(UserMapper.class);
		
		// 3.使用mapper对象，调用方法执行
		// 创建用户对象
		User user = new User();
		user.setUsername("%小%");
		user.setSex("1");
		
		List<User> list = mapper.queryUserByNameAndSex(user);
		for(User u:list){
			System.out.println(u);
		}
		
		// 4.释放资源
		sqlSession.close();
	}
	
	// 测试动态修改用户数据
	@Test
	public void dynamicUserByIdTest(){
		
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession(true);
		
		// 2.使用sqlSession对象，获取mapper代理对象
		UserMapper mapper = sqlSession.getMapper(UserMapper.class);
		
		// 3.使用mapper对象，调用方法执行
		// 创建用户对象
		User user = new User();
		user.setUsername("张三丰");
		user.setSex("1");
		user.setId(24);
		
		mapper.dynamicUserById(user);
		
		// 4.释放资源
		sqlSession.close();
		
	}
	
	// 测试批量新增用户
	@Test
	public void batchInsertUserTest(){
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession(true);
		
		// 2.使用sqlSession对象，获取mapper代理对象
		UserMapper mapper = sqlSession.getMapper(UserMapper.class);
		
		// 3.使用mapper对象，调用方法执行
		// 创建用户集合List
		List<User> list = new ArrayList<User>();
		for(int i=0;i<3;i++){
			// 创建用户对象
			User user = new User();
			user.setUsername("用户名称"+i);
			user.setBirthday(new Date());
			user.setSex("1");
			user.setAddress("用户地址"+i);
			
			list.add(user);
		}
		
		mapper.batchInsertUser(list);
		
		// 4.释放资源
		sqlSession.close();
	}
	
	// 测试批量删除用户
	@Test
	public void batchDeleteUserTest(){
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession(true);
		
		// 2.使用sqlSession对象，获取mapper代理对象
		UserMapper mapper = sqlSession.getMapper(UserMapper.class);
		
		// 3.使用mapper对象，调用方法执行
		Integer[] ids = {52,53,54};
		
		mapper.batchDeleteUser(ids);
		
		// 4.释放资源
		sqlSession.close();
	}
	
	// 测试查询用户数据，并且关联查询出所有的订单数据
	@Test
	public void queryUsersAndOrdersTest(){
		// 1.创建sqlSession对象
		SqlSession sqlSession = this.sqlSessionFactory.openSession();
		
		// 2.使用sqlSession对象，获取mapper代理对象
		UserMapper mapper = sqlSession.getMapper(UserMapper.class);
		
		// 3.使用mapper对象，调用方法执行
		List<User> list = mapper.queryUsersAndOrders();
		for(User u:list){
			System.out.println(u);
		}
		
		// 4.释放资源
		sqlSession.close();
	}
	
	
	
	

}
