package cn.itcast.mybatis.mapper;

import tk.mybatis.mapper.common.Mapper;
import cn.itcast.mybatis.pojo.Notice;

/**
 * NoticeMapper
 * @author LEE.SIU.WAH
 * @email lixiaohua7@163.com
 * @date 2017年11月23日 上午10:31:52
 * @version 1.0
 */
public interface NoticeMapper extends Mapper<Notice> {
	
}
