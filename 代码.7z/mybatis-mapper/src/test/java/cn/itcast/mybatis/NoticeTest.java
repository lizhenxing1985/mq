package cn.itcast.mybatis;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import tk.mybatis.mapper.mapperhelper.MapperHelper;

import com.github.pagehelper.ISelect;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.itcast.mybatis.mapper.NoticeMapper;
import cn.itcast.mybatis.pojo.Notice;

/**
 * NoticeTest
 * @author LEE.SIU.WAH
 * @email lixiaohua7@163.com
 * @date 2017年11月23日 上午10:34:46
 * @version 1.0
 */
public class NoticeTest {
	
	/** 定义数据访问接口 */
	private NoticeMapper noticeMapper;
	private SqlSession sqlSession;
	
	@Before
	public void before()throws Exception{
		System.out.println("======before=======");
		InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
		/** 获取SqlSession */
		sqlSession = sqlSessionFactory.openSession();
		/** 获取数据访问接口代理对象 */
		noticeMapper = sqlSession.getMapper(NoticeMapper.class);
		
		/** 创建MapperHelper */
		MapperHelper helper = new MapperHelper();
		/** 注册自己的接口 (也就继承了通用Mapper接口) */
		helper.registerMapper(NoticeMapper.class);
		/** 执行配置信息 */
		helper.processConfiguration(sqlSession.getConfiguration());
	}
	
	/** 查询全部 */
	@Test
	public void findAll(){
		List<Notice> notices = noticeMapper.selectAll();
		System.out.println(notices);
	}
	
	/** 分页查询(第二种方式) */
	@Test
	public void findByPage(){
		/** 开始分页 limit ?,? */
		PageInfo<Notice>  pageInfo = PageHelper.startPage(2, 2)
				.doSelectPageInfo(new ISelect() {
			@Override
			public void doSelect() {
				 noticeMapper.selectAll();
			}
		});
		
		System.out.println("当前页码：" + pageInfo.getPageNum());
		System.out.println("每页显示的记录数：" + pageInfo.getPageSize());
		System.out.println("总记录数：" + pageInfo.getTotal());
		System.out.println("总页数：" + pageInfo.getPages());
		System.out.println("上一页：" + pageInfo.getPrePage());
		System.out.println("下一页：" + pageInfo.getNextPage());
		for (Notice notice : pageInfo.getList()){
			System.out.println(notice);
		}
	}
	
	/** 查询一条 */
	@Test
	public void findOne(){
		Notice notice = noticeMapper.selectByPrimaryKey(1L);
		System.out.println(notice);
	}
	
	/** 添加 */
	@Test
	public void save(){
		Notice notice = new Notice();
		notice.setTitle("aa");
		notice.setContent("bbb");
		int res = noticeMapper.insertSelective(notice);
		System.out.println("受影响的行数：" + res);
		System.out.println("主键id:" + notice.getId());
	}
	
	/** 修改 */
	@Test
	public void update(){
		Notice notice = new Notice();
		notice.setId(62L);
		notice.setTitle("aa1");
		//notice.setContent("bbb1");
		int res = noticeMapper.updateByPrimaryKeySelective(notice);
		System.out.println("受影响的行数：" + res);
	}
	
	/** 删除 */
	@Test
	public void delete(){
		int res = noticeMapper.deleteByPrimaryKey(62L);
		System.out.println("受影响的行数：" + res);
	}
	
	
	@After
	public void after(){
		System.out.println("======after=======");
		sqlSession.commit();
		sqlSession.close();
		
	}
}
