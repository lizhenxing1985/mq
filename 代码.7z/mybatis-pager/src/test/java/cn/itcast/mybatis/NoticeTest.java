package cn.itcast.mybatis;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.github.pagehelper.ISelect;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import cn.itcast.mybatis.mapper.NoticeMapper;
import cn.itcast.mybatis.pojo.Notice;

/**
 * NoticeTest
 * @author LEE.SIU.WAH
 * @email lixiaohua7@163.com
 * @date 2017年11月23日 上午10:34:46
 * @version 1.0
 */
public class NoticeTest {
	
	/** 定义数据访问接口 */
	private NoticeMapper noticeMapper;
	private SqlSession sqlSession;
	
	@Before
	public void before()throws Exception{
		System.out.println("======before=======");
		InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
		/** 获取SqlSession */
		sqlSession = sqlSessionFactory.openSession();
		/** 获取数据访问接口代理对象 */
		noticeMapper = sqlSession.getMapper(NoticeMapper.class);
	}
	
	/** 查询全部 */
	@Test
	public void findAll(){
		List<Notice> notices = noticeMapper.findAll();
		System.out.println(notices);
	}
	
	/** 分页查询(第一种方式) */
	@Test
	public void findByPage1(){
		/** 开始分页 limit ?,? */
		PageHelper.startPage(1, 2);
		/** 返回得是Page接口的代理对象 */
		List<Notice> notices = noticeMapper.findAll();
		/** 把接口代理对象转化成PageInfo对象 */
		PageInfo<Notice> pageInfo = new PageInfo<>(notices);
		System.out.println("当前页码：" + pageInfo.getPageNum());
		System.out.println("每页显示的记录数：" + pageInfo.getPageSize());
		System.out.println("总记录数：" + pageInfo.getTotal());
		System.out.println("总页数：" + pageInfo.getPages());
		System.out.println("上一页：" + pageInfo.getPrePage());
		System.out.println("下一页：" + pageInfo.getNextPage());
		for (Notice notice : pageInfo.getList()){
			System.out.println(notice);
		}
		
		/** 不为分页查询 */
		List<Notice> a = noticeMapper.findAll();
		
	}
	
	/** 分页查询(第二种方式) */
	@Test
	public void findByPage2(){
		/** 开始分页 limit ?,? */
		PageInfo<Notice>  pageInfo = PageHelper.startPage(2, 2)
				.doSelectPageInfo(new ISelect() {
			@Override
			public void doSelect() {
				noticeMapper.findAll();
			}
		});
		
		System.out.println("当前页码：" + pageInfo.getPageNum());
		System.out.println("每页显示的记录数：" + pageInfo.getPageSize());
		System.out.println("总记录数：" + pageInfo.getTotal());
		System.out.println("总页数：" + pageInfo.getPages());
		System.out.println("上一页：" + pageInfo.getPrePage());
		System.out.println("下一页：" + pageInfo.getNextPage());
		for (Notice notice : pageInfo.getList()){
			System.out.println(notice);
		}
		
		
	}
	
	
	@After
	public void after(){
		System.out.println("======after=======");
		sqlSession.commit();
		sqlSession.close();
		
	}
}
